/** @license See the LICENSE file. */
declare const version = "2.0.0";
export { version };
