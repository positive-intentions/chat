"use strict";
/** @license See the LICENSE file. */
Object.defineProperty(exports, "__esModule", { value: true });
exports.version = void 0;
// This code is auto-generated, do not modify this file!
var version = '2.0.0';
exports.version = version;
//# sourceMappingURL=version.js.map