"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SupportedModels = void 0;
var SupportedModels;
(function (SupportedModels) {
    SupportedModels["MediaPipeHands"] = "MediaPipeHands";
})(SupportedModels = exports.SupportedModels || (exports.SupportedModels = {}));
//# sourceMappingURL=types.js.map