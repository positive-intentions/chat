"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=shape_interfaces.js.map